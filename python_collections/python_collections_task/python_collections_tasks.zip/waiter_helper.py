# 2. Waiter Helper task


starters = ["Vegetable Pakoras", "Chicken Pakoras", "Chicken Wings", "Paneer Salad"]
mains = ["Chicken Bhuna", "Beef Madras", "Beef Jalfrezi", "Vegetable Korma", "Vegetable Biriyani"]
desserts = ["Mango Sorbet", "Chocolate Ice Cream", "Mixed Fruit Salad", "Chocolate Fudge Cake"]

print(starters)
print(mains)
print(desserts)

# First order
print(starters[0])
print(mains[2])
print(desserts[1])

# Second order
print(starters[3])
print(mains[4])
print(desserts[0])

# Third order
print(starters[2])
print(mains[0])
print(desserts[3])

order_1 = [starters[0] + mains[2] + desserts[1]]
print(order_1)

order_2 = [starters[3] + mains[4] + desserts[0]]
print(order_2)

order_3 = [starters[2] + mains[0] + desserts[3]]
print(order_3)