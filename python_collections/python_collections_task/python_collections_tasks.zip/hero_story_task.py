story1 = {
    "start": "Illusion Girl saw the obesity epidemic was rife",
    "middle": "She realised she had the power to make healthy food items appear and taste the same as junk food",
    "end": "With her powers of illusion, Illusion Girl helped the population live longer, healthier lives"
}
print(story1)

print(type(story1))

print(story1.keys())
print(story1.values())
print(story1["start"])
print(story1["middle"])
print(story1["end"])

story1["hero"]= "Illusion Girl"
print(story1)